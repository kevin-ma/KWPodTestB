

#import <Foundation/Foundation.h>
#import <KWPodTestA/KWFunction.h>

@interface KWPodTestB : KWFunction

+ (void)start;

@end
