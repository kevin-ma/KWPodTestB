#import "KWPodTestB.h"

@implementation KWPodTestB

+ (void)start {
    [super start];
    NSLog(@"start KWPodTestB");
}

@end
